# VISION — Eye Disease Detection & Prevention using AI

Project-1, B.Tech Computer Science & Engineering, Medi-Caps University, Indore.
Sujal Bekariya (EN23CS3011040) · Sumit Mahato (EN23CS3011043) · Suhani Mehta (EN23CS3011039)
Guides: Prof. Jyotsana Goyal · Prof. Sanket Gupta · Prof. Kamini Vishwakarma

Two CNNs behind one web app. **Model A** reads a fundus (retina) photograph and
screens for diabetic retinopathy, glaucoma, cataract and AMD. **Model B** reads
an ordinary close-up phone photo and screens for conjunctivitis, styes and
redness. Both return a confidence score, a Grad-CAM heatmap showing which pixels
drove the decision, and specific prevention and next-step guidance.

> VISION is a screening aid, not a medical device, and cannot diagnose anything.

---

## 1. What is in here

```
app.py                      Flask app: UI + JSON API
templates/index.html        the entire front end (no build step)
src/
  config.py                 paths, task definitions, hyperparameters — edit here
  models.py                 EfficientNetB0 / MobileNetV2 transfer-learning graphs
  data.py                   tf.data pipelines, class weights, class-list persistence
  train.py                  two-stage trainer (frozen head, then fine-tune)
  evaluate.py               accuracy / precision / recall / F1 / AUC / confusion matrix
  gradcam.py                explainability heatmaps
  inference.py              lazy model loading and the prediction path
  advice.py                 condition summaries and prevention guidance
scripts/
  prepare_odir.py           ODIR-5K -> per-eye class folders, split by patient
  split_dataset.py          any class-folder dataset -> train/val/test
  smoke_test.py             end-to-end pipeline check on synthetic images
notebooks/train_colab.ipynb Colab notebook for free GPU training
Dockerfile, render.yaml, Procfile, docker-compose.yml
```

## 2. Install

```bash
git clone <your-repo-url> vision && cd vision
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements-train.txt
```

Python 3.10–3.12. Training on CPU is slow but works; use Colab (section 6) for
the real runs.

## 3. Check the code works before you have any data

```bash
python scripts/smoke_test.py
```

This generates synthetic images, trains for one epoch, evaluates, runs Grad-CAM,
and exercises the HTTP API the same way the browser does. It cleans up after
itself. If it prints `PASS`, every part of the system is wired correctly and
anything that breaks later is a data problem, not a code problem.

The accuracy it prints is meaningless — the synthetic classes are trivially
separable. Do not put those numbers anywhere near your report.

## 4. Get the real data

### Model A — internal (ODIR-5K)

Download from
<https://www.kaggle.com/datasets/andrewmvd/ocular-disease-recognition-odir5k>,
unzip it, then:

```bash
python scripts/prepare_odir.py --source ~/Downloads/odir5k
```

Two things this script does that a naive `train_test_split` does not, and both
are worth a paragraph in your methodology chapter:

1. **Per-eye labels.** ODIR's N/D/G/C/A columns are recorded per *patient*. A
   patient marked glaucomatous often has one healthy eye, so patient-level
   labels teach the model that healthy retinas are diseased. The script parses
   the per-eye diagnostic keyword columns instead, and drops images whose
   keywords indicate a photography problem (lens dust, low image quality)
   rather than a finding.
2. **Splitting by patient.** Both eyes of one person are strongly correlated. If
   the left eye is in train and the right in test, your reported test accuracy
   is inflated by several points. The split is done over patient IDs.

Start with `--max-per-class 700` to get a first result quickly, then remove the
cap for the final run.

### Model B — external (close-up photos)

There is no single canonical dataset here. Collect a folder per class from
Kaggle eye-disease image datasets, arrange them as:

```
downloaded/conjunctivitis/*.jpg
downloaded/normal/*.jpg
downloaded/stye/*.jpg
```

then:

```bash
python scripts/split_dataset.py --source downloaded --task external
```

This drops corrupt files, images under 64 px, and byte-identical duplicates —
scraped eye-photo datasets are full of all three, and duplicates spanning train
and test are the most common cause of a suspiciously high score.

Class folder names must match the keys in `src/advice.py` (`conjunctivitis`,
`stye`, `redness`, `normal`) or the app will show the raw folder name with no
guidance attached. Add new entries to `ADVICE` if you add a class.

## 5. Train and evaluate

```bash
python -m src.train --task internal
python -m src.evaluate --task internal

python -m src.train --task external
python -m src.evaluate --task external
```

Training runs in two stages. Stage 1 trains only the new classifier head with
the pretrained backbone frozen, so the large random gradients from an untrained
head cannot destroy the ImageNet filters. Stage 2 unfreezes the top 40 backbone
layers at `lr=1e-5` so deep filters adapt to retinal texture. BatchNorm layers
stay frozen throughout — unfreezing them at small batch sizes makes the running
statistics drift and validation accuracy collapse.

Class weights are applied by default because ODIR is heavily imbalanced. Without
them the model predicts "normal" for everything and still scores around 50%,
which looks acceptable in a table and is useless in a clinic. This is the
imbalance problem Bhati et al. [1] address with DKCNet.

`evaluate.py` writes to `reports/`:

| File | Use in the report |
|---|---|
| `<task>_metrics.json` | accuracy, macro/weighted precision, recall, F1, one-vs-rest AUC, per-class breakdown |
| `<task>_confusion_matrix.png` | the figure for the Results chapter |
| `<task>_confusion_matrix.csv` | raw counts if you want to re-plot |
| `<task>_training_curves.png` | loss/accuracy curves — shows whether you overfit |

Report **macro F1 and per-class recall**, not just accuracy. On an imbalanced
dataset accuracy hides exactly the failure that matters: missing the rare
disease. Recall on the AMD row of the confusion matrix is the number an examiner
should ask about.

### Useful flags

```bash
python -m src.train --task internal --head-epochs 12 --finetune-epochs 20
python -m src.train --task internal --batch-size 16      # if you run out of GPU memory
python -m src.train --task internal --no-class-weights   # ablation for the report
python -m src.evaluate --task internal --split val
```

To swap the backbone, change `backbone=` in `src/config.py`. `efficientnetb0`,
`efficientnetb3`, `mobilenetv2` and `resnet50` are wired up; comparing two of
them is an easy extra table for the report.

## 6. Training on Colab (free GPU)

Open `notebooks/train_colab.ipynb` in Colab, set Runtime → Change runtime type →
T4 GPU, and run the cells. It clones the repo, pulls the dataset with the Kaggle
API, trains both models and downloads the `.keras` files. A full ODIR run takes
roughly 25–40 minutes on a T4.

## 7. Run the web app

```bash
python app.py                  # http://localhost:5000
```

Production:

```bash
gunicorn app:app --workers 1 --threads 4 --timeout 180 --bind 0.0.0.0:8000
```

Use **one worker**. Each worker loads its own copy of both models into memory,
which exceeds the RAM on every free hosting tier. Threads handle concurrent
uploads fine because TensorFlow releases the GIL during inference.

The app starts even with no trained models. It reports which ones are missing on
`/api/health` and disables the matching option in the UI, so a broken Model B
never takes Model A down with it.

### API

```
GET  /api/health     which models are present, their size and class lists
GET  /api/tasks      task metadata, plus test metrics if you have run evaluate
POST /api/predict    multipart: image=<file>, task=internal|external, gradcam=true|false
```

```bash
curl -s -F "image=@retina.jpg" -F "task=internal" -F "gradcam=false" \
     http://localhost:5000/api/predict | python -m json.tool
```

Response:

```json
{
  "task": "internal",
  "prediction": "diabetic_retinopathy",
  "label": "Diabetic retinopathy",
  "confidence": 0.8731,
  "low_confidence": false,
  "urgency": "soon",
  "summary": "...",
  "prevention": ["..."],
  "next_steps": ["..."],
  "probabilities": [{"class": "...", "label": "...", "probability": 0.87}],
  "gradcam": "data:image/png;base64,...",
  "disclaimer": "..."
}
```

If top-1 probability falls below `LOW_CONFIDENCE_THRESHOLD` (0.45 in
`src/config.py`) the app refuses to name a condition and asks for a better
photo. A screening tool that abstains when unsure is safer than one that always
answers, and it is a design decision worth defending in the viva.

## 8. Deploy

**Hugging Face Spaces** is the easiest free option that tolerates a
400 MB TensorFlow image and 100 MB of weights.

1. Create a Space → Docker → Blank.
2. Push this repo, including the trained `models/*.keras` and
   `models/*_classes.json` files (use `git lfs track "*.keras"` if they exceed
   Git's limit).
3. The Space serves on port 7860, which the `Dockerfile` already sets.

**Render**: push to GitHub, then New → Blueprint and select the repo;
`render.yaml` configures everything. The free tier sleeps after inactivity, so
the first request after a pause takes 30–60 seconds to wake and load TensorFlow.

**Local Docker**:

```bash
docker compose up --build       # http://localhost:7860
```

Weights are mounted from `./models`, so retraining does not require a rebuild.

Set `VISION_WARMUP=1` to load both models at startup rather than on the first
request. It makes the first prediction fast and the boot slow — right for a live
demo in a viva, wrong for a free tier that restarts often.

## 9. Known limitations — say these before the examiner does

- **Distribution shift.** ODIR images come from specific retinal cameras. A
  photograph taken on different equipment, or a phone photo held up to a lens,
  can fall outside what the model has seen. Reported accuracy is accuracy on
  ODIR-style images, not accuracy in the field.
- **Single-label simplification.** Real patients have more than one condition at
  once. Model A is single-label and images with multiple findings were dropped
  during preparation. Extending to multi-label (sigmoid output, binary
  cross-entropy, per-class thresholds) is the obvious next step and is where
  Bhati et al. [1] and the multi-label direction in Muchuchuti & Viriri [5] lead.
- **Model B's dataset.** Assembled from public sources of uneven quality and
  much smaller than ODIR. Treat its numbers as weaker evidence and say so.
- **Grad-CAM is a sanity check, not a lesion detector.** It shows what the model
  attended to. If it highlights the black border around a fundus image, the
  model has learned a camera artifact, which is a finding worth reporting.
- **No severity grading.** The system says "diabetic retinopathy", not which
  stage, and staging is what drives treatment decisions.

## 10. Mapping to the synopsis objectives

| Objective | Where it is implemented |
|---|---|
| 1. Collect and prepare two public datasets | `scripts/prepare_odir.py`, `scripts/split_dataset.py` |
| 2. CNN for internal disease | `src/models.py` (EfficientNetB0), `src/train.py --task internal` |
| 3. CNN for external conditions | `src/models.py` (MobileNetV2), `src/train.py --task external` |
| 4. One web application over both | `app.py`, `templates/index.html` |
| 5. Accuracy, precision, recall, F1, confusion matrices | `src/evaluate.py` → `reports/` |
| Beyond the synopsis: explainability | `src/gradcam.py` — addresses the gap named in [5] |
| Beyond the synopsis: prevention guidance | `src/advice.py` |

## References

[1] A. Bhati, N. Gour, P. Khanna, A. Ojha, "Discriminative kernel convolution
network for multi-label ophthalmic disease detection on imbalanced fundus image
dataset", *Computers in Biology and Medicine*, vol. 153, art. 106519, 2023.

[2] J. Kaur et al., "Multiclass Classification and Identification of the External
Eye Diseases using Deep CNN", *Indian Journal of Science and Technology*,
vol. 17, no. 12, pp. 1–8, 2024.

[3] Y. Li, X. Wang, H. Fu et al., "Multimodal Information Fusion for Glaucoma and
Diabetic Retinopathy Classification", *OMIA 2022*, LNCS vol. 13576, Springer,
pp. 53–62, 2022.

[4] R. P. Bhatta, "Diabetes Prediction Using Random Forest and XGBoost Machine
Learning Algorithm", *Journal of Engineering Technology and Planning*, vol. 6,
no. 1, pp. 88–103, 2025.

[5] S. Muchuchuti, S. Viriri, "Retinal Disease Detection Using Deep Learning
Techniques: A Comprehensive Review", *Journal of Imaging*, vol. 9, no. 4, 2023.

[6] ODIR-5K: Ocular Disease Intelligent Recognition Dataset, Kaggle.
